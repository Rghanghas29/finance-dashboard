# FinFlow — Finance Dashboard

A clean, modern personal finance dashboard built with **React + Vite + Tailwind CSS**.

## Features

- **Dashboard Overview** — Summary cards, 6-month area chart, spending donut chart, recent transactions
- **Transactions** — Searchable, filterable, sortable table with add / edit / delete
- **Insights** — Spending trends, category breakdown, monthly comparison bar chart, savings rate
- **Role-Based UI** — Admin can add/edit/delete; Viewer is read-only
- **Dark Mode** — Toggle in sidebar, persisted to localStorage
- **Export CSV** — Download filtered transactions
- **localStorage persistence** — Transactions survive page refresh
- **Fully responsive** — Mobile-friendly with slide-out drawer nav

---

## Folder Structure

```
finance-dashboard/
├── public/
│   └── favicon.svg
├── src/
│   ├── components/
│   │   ├── dashboard/
│   │   │   ├── DashboardPage.jsx
│   │   │   ├── SummaryCards.jsx
│   │   │   ├── BalanceTrendChart.jsx
│   │   │   ├── CategoryChart.jsx
│   │   │   └── RecentTransactions.jsx
│   │   ├── transactions/
│   │   │   ├── TransactionsPage.jsx
│   │   │   └── TransactionModal.jsx
│   │   ├── insights/
│   │   │   └── InsightsPage.jsx
│   │   └── layout/
│   │       └── Sidebar.jsx
│   ├── context/
│   │   └── AppContext.jsx
│   ├── data/
│   │   └── mockData.js
│   ├── utils/
│   │   └── helpers.js
│   ├── App.jsx
│   ├── main.jsx
│   └── index.css
├── index.html
├── package.json
├── vite.config.js
├── tailwind.config.js
└── postcss.config.js
```

---

## Quick Start

### Prerequisites
- **Node.js** v18 or higher
- **npm** v8 or higher

### Steps

```bash
# 1. Navigate into the project folder
cd finance-dashboard

# 2. Install dependencies
npm install

# 3. Start the dev server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### Build for Production

```bash
npm run build
npm run preview
```

---

## Tech Stack

| Tool | Purpose |
|------|---------|
| React 18 | UI framework |
| Vite 5 | Build tool / dev server |
| Tailwind CSS 3 | Utility-first styling |
| Recharts | Charts (area, donut, bar) |
| lucide-react | Icons |
| date-fns | Date formatting & math |

---

## Usage Notes

- **Role Switcher** is in the sidebar bottom. Switch between **Admin** (can add/edit/delete) and **Viewer** (read-only).
- **Dark Mode** toggle is also in the sidebar — persists across sessions.
- **Transactions** are saved to `localStorage` automatically.
- **Export CSV** button in the Transactions page exports the currently filtered list.
- All amounts are in **Indian Rupees (₹)**.

---

## Customising Mock Data

Edit `src/data/mockData.js` to change the seed transactions, categories, or colours. The `CATEGORIES` array and `CATEGORY_COLORS` object control what shows up in the dropdowns and charts.
