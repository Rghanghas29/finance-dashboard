export function formatINR(amount) {
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatDate(dateStr) {
  return new Date(dateStr).toLocaleDateString('en-IN', {
    day: '2-digit', month: 'short', year: 'numeric',
  });
}

export function generateId() {
  return Math.random().toString(36).slice(2, 10) + Date.now().toString(36);
}

export function exportToCSV(transactions) {
  const header = ['Date', 'Description', 'Category', 'Type', 'Amount (₹)'];
  const rows = transactions.map(t => [
    t.date, t.description, t.category, t.type, t.amount,
  ]);
  const csv = [header, ...rows].map(r => r.join(',')).join('\n');
  const blob = new Blob([csv], { type: 'text/csv' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = 'finflow_transactions.csv';
  a.click();
  URL.revokeObjectURL(url);
}

export function getFilteredSorted(transactions, filter, search, sort) {
  let result = [...transactions];

  if (filter !== 'all') result = result.filter(t => t.type === filter);

  if (search.trim()) {
    const q = search.toLowerCase();
    result = result.filter(t =>
      t.category.toLowerCase().includes(q) ||
      t.description.toLowerCase().includes(q) ||
      t.type.toLowerCase().includes(q)
    );
  }

  result.sort((a, b) => {
    let av = a[sort.key], bv = b[sort.key];
    if (sort.key === 'date') { av = new Date(av); bv = new Date(bv); }
    return sort.dir === 'asc' ? (av > bv ? 1 : -1) : (av < bv ? 1 : -1);
  });

  return result;
}
