import { useState } from 'react';
import {
  LayoutDashboard, ArrowLeftRight, Lightbulb,
  Moon, Sun, Menu, X, TrendingUp, ShieldCheck, Eye,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';

const NAV = [
  { key: 'dashboard',    label: 'Dashboard',    Icon: LayoutDashboard },
  { key: 'transactions', label: 'Transactions', Icon: ArrowLeftRight   },
  { key: 'insights',     label: 'Insights',     Icon: Lightbulb        },
];

export default function Sidebar({ page, setPage }) {
  const { state, dispatch, darkMode, setDarkMode } = useApp();
  const [open, setOpen] = useState(false);

  const SideContent = () => (
    <div className="flex flex-col h-full">
      {/* Logo */}
      <div className="flex items-center gap-3 px-4 py-6 border-b border-gray-100 dark:border-gray-800">
        <div className="w-9 h-9 rounded-xl bg-brand-500 flex items-center justify-center">
          <TrendingUp className="w-5 h-5 text-white" />
        </div>
        <span className="text-lg font-semibold tracking-tight">FinFlow</span>
      </div>

      {/* Nav */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {NAV.map(({ key, label, Icon }) => (
          <button
            key={key}
            onClick={() => { setPage(key); setOpen(false); }}
            className={`nav-link w-full ${page === key ? 'active' : ''}`}
          >
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </nav>

      {/* Role switcher */}
      <div className="px-3 py-3 border-t border-gray-100 dark:border-gray-800">
        <p className="text-xs text-gray-400 dark:text-gray-500 px-2 mb-2 uppercase tracking-wider">Role</p>
        <div className="flex gap-2">
          {['viewer', 'admin'].map(r => (
            <button
              key={r}
              onClick={() => dispatch({ type: 'SET_ROLE', payload: r })}
              className={`flex-1 flex items-center justify-center gap-1.5 py-1.5 rounded-lg text-xs font-medium transition-all
                ${state.role === r
                  ? 'bg-brand-500 text-white'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-500 dark:text-gray-400 hover:bg-gray-200 dark:hover:bg-gray-700'}`}
            >
              {r === 'admin' ? <ShieldCheck className="w-3 h-3" /> : <Eye className="w-3 h-3" />}
              {r.charAt(0).toUpperCase() + r.slice(1)}
            </button>
          ))}
        </div>
      </div>

      {/* Dark mode */}
      <div className="px-3 py-4 border-t border-gray-100 dark:border-gray-800">
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="btn-ghost w-full justify-start"
        >
          {darkMode ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
          {darkMode ? 'Light Mode' : 'Dark Mode'}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Mobile top bar */}
      <div className="lg:hidden flex items-center justify-between px-4 py-3 bg-white dark:bg-[#1a1f2e] border-b border-gray-100 dark:border-gray-800 sticky top-0 z-30">
        <div className="flex items-center gap-2">
          <div className="w-7 h-7 rounded-lg bg-brand-500 flex items-center justify-center">
            <TrendingUp className="w-4 h-4 text-white" />
          </div>
          <span className="font-semibold">FinFlow</span>
        </div>
        <button onClick={() => setOpen(!open)} className="btn-ghost p-2">
          {open ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
        </button>
      </div>

      {/* Mobile drawer */}
      {open && (
        <div className="lg:hidden fixed inset-0 z-40" onClick={() => setOpen(false)}>
          <div className="absolute inset-0 bg-black/40" />
          <div className="absolute left-0 top-0 h-full w-64 bg-white dark:bg-[#1a1f2e] shadow-xl" onClick={e => e.stopPropagation()}>
            <SideContent />
          </div>
        </div>
      )}

      {/* Desktop sidebar */}
      <aside className="hidden lg:flex flex-col w-60 shrink-0 h-screen sticky top-0 bg-white dark:bg-[#1a1f2e] border-r border-gray-100 dark:border-gray-800">
        <SideContent />
      </aside>
    </>
  );
}
