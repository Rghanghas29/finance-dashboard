import { subMonths, format } from 'date-fns';
import { TrendingUp, TrendingDown, Award, AlertCircle, BarChart2 } from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatINR } from '../../utils/helpers';
import { generateCategoryData, CATEGORY_COLORS } from '../../data/mockData';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';

function monthLabel(offset) {
  return format(subMonths(new Date(), offset), 'MMM yyyy');
}

export default function InsightsPage() {
  const { state } = useApp();
  const { transactions } = state;

  const thisMonth = format(new Date(), 'yyyy-MM');
  const lastMonth = format(subMonths(new Date(), 1), 'yyyy-MM');

  const expense = (month) =>
    transactions.filter(t => t.type === 'expense' && t.date.startsWith(month)).reduce((s, t) => s + t.amount, 0);
  const income = (month) =>
    transactions.filter(t => t.type === 'income' && t.date.startsWith(month)).reduce((s, t) => s + t.amount, 0);

  const thisExp = expense(thisMonth);
  const lastExp = expense(lastMonth);
  const thisInc = income(thisMonth);
  const lastInc = income(lastMonth);

  const expChange = lastExp ? ((thisExp - lastExp) / lastExp) * 100 : 0;
  const incChange = lastInc ? ((thisInc - lastInc) / lastInc) * 100 : 0;

  const categoryData = generateCategoryData(transactions);
  const topCategory = categoryData[0];

  // Monthly comparison bar chart data (last 3 months)
  const barData = [2, 1, 0].map(offset => ({
    month: format(subMonths(new Date(), offset), 'MMM'),
    income: income(format(subMonths(new Date(), offset), 'yyyy-MM')),
    expense: expense(format(subMonths(new Date(), offset), 'yyyy-MM')),
  }));

  const savingsRate = thisInc > 0 ? ((thisInc - thisExp) / thisInc) * 100 : 0;

  const insights = [
    {
      Icon: expChange > 0 ? TrendingUp : TrendingDown,
      color: expChange > 0 ? 'text-red-500' : 'text-green-500',
      bg: expChange > 0 ? 'bg-red-50 dark:bg-red-900/20' : 'bg-green-50 dark:bg-green-900/20',
      title: 'Expense Trend',
      body: `Spending ${expChange > 0 ? 'increased' : 'decreased'} by ${Math.abs(expChange).toFixed(1)}% vs ${monthLabel(1)}.`,
    },
    {
      Icon: Award,
      color: 'text-amber-500',
      bg: 'bg-amber-50 dark:bg-amber-900/20',
      title: 'Top Spending Category',
      body: topCategory
        ? `${topCategory.name} accounts for ${formatINR(topCategory.value)} in expenses.`
        : 'No expense data yet.',
    },
    {
      Icon: BarChart2,
      color: 'text-brand-600 dark:text-brand-400',
      bg: 'bg-brand-50 dark:bg-brand-900/20',
      title: 'Savings Rate This Month',
      body: `You are saving ${savingsRate.toFixed(1)}% of your income this month.`,
    },
    {
      Icon: incChange >= 0 ? TrendingUp : TrendingDown,
      color: incChange >= 0 ? 'text-green-500' : 'text-red-400',
      bg: incChange >= 0 ? 'bg-green-50 dark:bg-green-900/20' : 'bg-red-50 dark:bg-red-900/20',
      title: 'Income Trend',
      body: `Income ${incChange >= 0 ? 'up' : 'down'} ${Math.abs(incChange).toFixed(1)}% vs ${monthLabel(1)}.`,
    },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-xl font-semibold">Insights</h1>

      {/* Insight cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {insights.map(({ Icon, color, bg, title, body }) => (
          <div key={title} className="card p-5 flex gap-4 animate-fade-in">
            <div className={`w-10 h-10 rounded-xl ${bg} flex items-center justify-center shrink-0`}>
              <Icon className={`w-5 h-5 ${color}`} />
            </div>
            <div>
              <p className="font-medium text-sm mb-1">{title}</p>
              <p className="text-sm text-gray-500 dark:text-gray-400">{body}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Monthly comparison */}
      <div className="card p-5 animate-fade-in">
        <p className="font-semibold mb-4">3-Month Comparison</p>
        <ResponsiveContainer width="100%" height={220}>
          <BarChart data={barData} barCategoryGap="30%">
            <CartesianGrid strokeDasharray="3 3" strokeOpacity={0.4} />
            <XAxis dataKey="month" tick={{ fontSize: 12 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 11 }} axisLine={false} tickLine={false} tickFormatter={v => `₹${v / 1000}k`} width={48} />
            <Tooltip formatter={v => formatINR(v)} />
            <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
            <Bar dataKey="income"  name="Income"   fill="#22c55e" radius={[6, 6, 0, 0]} />
            <Bar dataKey="expense" name="Expenses" fill="#f87171" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </div>

      {/* Category breakdown */}
      <div className="card p-5 animate-fade-in">
        <p className="font-semibold mb-4">Category Breakdown</p>
        {categoryData.length === 0 ? (
          <p className="text-sm text-gray-400 text-center py-6">No expense data.</p>
        ) : (
          <div className="space-y-3">
            {categoryData.slice(0, 6).map(({ name, value }) => {
              const pct = categoryData[0].value > 0 ? (value / categoryData[0].value) * 100 : 0;
              return (
                <div key={name}>
                  <div className="flex justify-between text-sm mb-1">
                    <span className="font-medium">{name}</span>
                    <span className="font-mono text-gray-500 dark:text-gray-400">{formatINR(value)}</span>
                  </div>
                  <div className="h-2 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${pct}%`, background: CATEGORY_COLORS[name] || '#888' }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
