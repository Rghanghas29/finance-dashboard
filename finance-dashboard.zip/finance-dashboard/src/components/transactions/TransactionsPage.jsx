import { useState } from 'react';
import {
  Search, Plus, Download, Pencil, Trash2,
  ArrowUpDown, ArrowUp, ArrowDown,
} from 'lucide-react';
import { useApp } from '../../context/AppContext';
import { formatINR, formatDate, getFilteredSorted, exportToCSV } from '../../utils/helpers';
import { CATEGORY_COLORS } from '../../data/mockData';
import TransactionModal from './TransactionModal';

const FILTERS = ['all', 'income', 'expense'];

export default function TransactionsPage() {
  const { state, dispatch } = useApp();
  const { transactions, filter, search, sort, role } = state;
  const isAdmin = role === 'admin';

  const [modal, setModal] = useState(null); // null | 'add' | transaction object

  function toggleSort(key) {
    dispatch({
      type: 'SET_SORT',
      payload: sort.key === key
        ? { key, dir: sort.dir === 'asc' ? 'desc' : 'asc' }
        : { key, dir: 'desc' },
    });
  }

  function SortIcon({ col }) {
    if (sort.key !== col) return <ArrowUpDown className="w-3 h-3 opacity-40" />;
    return sort.dir === 'asc'
      ? <ArrowUp className="w-3 h-3 text-brand-500" />
      : <ArrowDown className="w-3 h-3 text-brand-500" />;
  }

  const filtered = getFilteredSorted(transactions, filter, search, sort);

  function handleDelete(id) {
    if (window.confirm('Delete this transaction?')) {
      dispatch({ type: 'DELETE_TRANSACTION', payload: id });
    }
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-semibold">Transactions</h1>
        <div className="flex gap-2">
          <button onClick={() => exportToCSV(filtered)} className="btn-ghost">
            <Download className="w-4 h-4" /> Export CSV
          </button>
          {isAdmin && (
            <button onClick={() => setModal('add')} className="btn-primary">
              <Plus className="w-4 h-4" /> Add
            </button>
          )}
        </div>
      </div>

      {/* Controls */}
      <div className="card p-4 flex flex-wrap gap-3 items-center">
        {/* Search */}
        <div className="relative flex-1 min-w-[180px]">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            className="input pl-9"
            placeholder="Search category or description…"
            value={search}
            onChange={e => dispatch({ type: 'SET_SEARCH', payload: e.target.value })}
          />
        </div>

        {/* Filter pills */}
        <div className="flex gap-1.5 bg-gray-100 dark:bg-gray-800 rounded-xl p-1">
          {FILTERS.map(f => (
            <button
              key={f}
              onClick={() => dispatch({ type: 'SET_FILTER', payload: f })}
              className={`px-3 py-1 rounded-lg text-xs font-medium capitalize transition-all
                ${filter === f
                  ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-gray-100 shadow-sm'
                  : 'text-gray-500 dark:text-gray-400 hover:text-gray-700 dark:hover:text-gray-200'}`}
            >
              {f}
            </button>
          ))}
        </div>
      </div>

      {/* Table */}
      <div className="card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-gray-100 dark:border-gray-800 text-xs text-gray-500 dark:text-gray-400">
                <th className="px-5 py-3 text-left font-medium">
                  <button onClick={() => toggleSort('date')} className="flex items-center gap-1">
                    Date <SortIcon col="date" />
                  </button>
                </th>
                <th className="px-5 py-3 text-left font-medium">Description</th>
                <th className="px-5 py-3 text-left font-medium">Category</th>
                <th className="px-5 py-3 text-left font-medium">Type</th>
                <th className="px-5 py-3 text-right font-medium">
                  <button onClick={() => toggleSort('amount')} className="flex items-center gap-1 ml-auto">
                    Amount <SortIcon col="amount" />
                  </button>
                </th>
                {isAdmin && <th className="px-5 py-3 text-right font-medium">Actions</th>}
              </tr>
            </thead>
            <tbody>
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={isAdmin ? 6 : 5} className="text-center py-16 text-gray-400">
                    No transactions found.
                  </td>
                </tr>
              ) : (
                filtered.map((t, i) => (
                  <tr
                    key={t.id}
                    className="border-b border-gray-50 dark:border-gray-800/60 hover:bg-gray-50 dark:hover:bg-gray-800/40 transition-colors"
                    style={{ animationDelay: `${i * 30}ms` }}
                  >
                    <td className="px-5 py-3.5 text-gray-500 dark:text-gray-400 whitespace-nowrap font-mono text-xs">
                      {formatDate(t.date)}
                    </td>
                    <td className="px-5 py-3.5 font-medium max-w-[200px] truncate">{t.description}</td>
                    <td className="px-5 py-3.5">
                      <span
                        className="inline-flex items-center gap-1.5 text-xs px-2.5 py-0.5 rounded-full font-medium text-white"
                        style={{ background: CATEGORY_COLORS[t.category] || '#888' }}
                      >
                        {t.category}
                      </span>
                    </td>
                    <td className="px-5 py-3.5">
                      <span className={t.type === 'income' ? 'badge-income' : 'badge-expense'}>
                        {t.type.charAt(0).toUpperCase() + t.type.slice(1)}
                      </span>
                    </td>
                    <td className={`px-5 py-3.5 text-right font-mono font-medium ${t.type === 'income' ? 'text-green-500' : 'text-red-400'}`}>
                      {t.type === 'income' ? '+' : '-'}{formatINR(t.amount)}
                    </td>
                    {isAdmin && (
                      <td className="px-5 py-3.5 text-right">
                        <div className="flex gap-1 justify-end">
                          <button
                            onClick={() => setModal(t)}
                            className="p-1.5 rounded-lg hover:bg-blue-50 dark:hover:bg-blue-900/30 text-blue-500 transition"
                          >
                            <Pencil className="w-3.5 h-3.5" />
                          </button>
                          <button
                            onClick={() => handleDelete(t.id)}
                            className="p-1.5 rounded-lg hover:bg-red-50 dark:hover:bg-red-900/30 text-red-400 transition"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    )}
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
        <div className="px-5 py-3 text-xs text-gray-400 border-t border-gray-100 dark:border-gray-800">
          {filtered.length} transaction{filtered.length !== 1 ? 's' : ''}
        </div>
      </div>

      {/* Modal */}
      {modal !== null && (
        <TransactionModal
          transaction={modal === 'add' ? null : modal}
          onClose={() => setModal(null)}
        />
      )}
    </div>
  );
}
