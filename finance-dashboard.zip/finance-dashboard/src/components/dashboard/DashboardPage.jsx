import SummaryCards from './SummaryCards';
import BalanceTrendChart from './BalanceTrendChart';
import CategoryChart from './CategoryChart';
import RecentTransactions from './RecentTransactions';

export default function DashboardPage({ setPage }) {
  return (
    <div className="space-y-5">
      <h1 className="text-xl font-semibold">Dashboard</h1>
      <SummaryCards />
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        <BalanceTrendChart />
        <CategoryChart />
      </div>
      <RecentTransactions onNavigate={() => setPage('transactions')} />
    </div>
  );
}
