import { formatINR, formatDate } from '../../utils/helpers';
import { useApp } from '../../context/AppContext';
import { CATEGORY_COLORS } from '../../data/mockData';

export default function RecentTransactions({ onNavigate }) {
  const { state } = useApp();
  const recent = [...state.transactions]
    .sort((a, b) => new Date(b.date) - new Date(a.date))
    .slice(0, 5);

  return (
    <div className="card p-5 animate-fade-in">
      <div className="flex items-center justify-between mb-4">
        <p className="font-semibold">Recent Transactions</p>
        <button onClick={onNavigate} className="text-xs text-brand-600 dark:text-brand-400 hover:underline">View all</button>
      </div>
      {recent.length === 0 ? (
        <p className="text-sm text-gray-400 text-center py-8">No transactions yet.</p>
      ) : (
        <div className="space-y-3">
          {recent.map(t => (
            <div key={t.id} className="flex items-center gap-3">
              <div
                className="w-8 h-8 rounded-xl flex items-center justify-center text-white text-xs font-bold shrink-0"
                style={{ background: CATEGORY_COLORS[t.category] || '#888' }}
              >
                {t.category.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-sm font-medium truncate">{t.description}</p>
                <p className="text-xs text-gray-400">{formatDate(t.date)}</p>
              </div>
              <p className={`text-sm font-mono font-medium shrink-0 ${t.type === 'income' ? 'text-green-500' : 'text-red-400'}`}>
                {t.type === 'income' ? '+' : '-'}{formatINR(t.amount)}
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
