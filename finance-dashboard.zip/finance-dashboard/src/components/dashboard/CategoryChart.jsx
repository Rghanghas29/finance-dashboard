import {
  PieChart, Pie, Cell, Tooltip, ResponsiveContainer, Legend,
} from 'recharts';
import { generateCategoryData } from '../../data/mockData';
import { useApp } from '../../context/AppContext';
import { formatINR } from '../../utils/helpers';

const CustomTooltip = ({ active, payload }) => {
  if (!active || !payload?.length) return null;
  const d = payload[0];
  return (
    <div className="card px-3 py-2 text-sm shadow-lg">
      <p className="font-medium">{d.name}</p>
      <p className="font-mono text-brand-600 dark:text-brand-400">{formatINR(d.value)}</p>
    </div>
  );
};

export default function CategoryChart() {
  const { state } = useApp();
  const data = generateCategoryData(state.transactions);

  return (
    <div className="card p-5 animate-fade-in">
      <p className="font-semibold mb-4">Spending by Category</p>
      <ResponsiveContainer width="100%" height={240}>
        <PieChart>
          <Pie
            data={data}
            cx="50%"
            cy="50%"
            innerRadius={60}
            outerRadius={90}
            paddingAngle={3}
            dataKey="value"
          >
            {data.map((entry, i) => (
              <Cell key={i} fill={entry.fill} />
            ))}
          </Pie>
          <Tooltip content={<CustomTooltip />} />
          <Legend
            iconType="circle"
            iconSize={8}
            wrapperStyle={{ fontSize: 11 }}
            formatter={(value) => <span style={{ color: 'inherit' }}>{value}</span>}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
