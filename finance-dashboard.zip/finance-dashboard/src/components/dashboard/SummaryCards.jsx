import { Wallet, TrendingUp, TrendingDown } from 'lucide-react';
import { formatINR } from '../../utils/helpers';
import { useApp } from '../../context/AppContext';

export default function SummaryCards() {
  const { state } = useApp();
  const { transactions } = state;

  const totalIncome  = transactions.filter(t => t.type === 'income' ).reduce((s, t) => s + t.amount, 0);
  const totalExpense = transactions.filter(t => t.type === 'expense').reduce((s, t) => s + t.amount, 0);
  const balance      = totalIncome - totalExpense;

  const cards = [
    {
      label: 'Total Balance',
      value: balance,
      Icon: Wallet,
      color: 'text-brand-600 dark:text-brand-400',
      bg:    'bg-brand-50 dark:bg-brand-900/30',
      trend: null,
    },
    {
      label: 'Total Income',
      value: totalIncome,
      Icon: TrendingUp,
      color: 'text-green-600 dark:text-green-400',
      bg:    'bg-green-50 dark:bg-green-900/30',
    },
    {
      label: 'Total Expenses',
      value: totalExpense,
      Icon: TrendingDown,
      color: 'text-red-500 dark:text-red-400',
      bg:    'bg-red-50 dark:bg-red-900/30',
    },
  ];

  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {cards.map(({ label, value, Icon, color, bg }) => (
        <div key={label} className="card p-5 flex items-center gap-4 animate-fade-in">
          <div className={`w-12 h-12 rounded-2xl ${bg} flex items-center justify-center shrink-0`}>
            <Icon className={`w-6 h-6 ${color}`} />
          </div>
          <div className="min-w-0">
            <p className="text-xs text-gray-500 dark:text-gray-400 mb-0.5">{label}</p>
            <p className={`text-xl font-semibold font-mono ${color} truncate`}>
              {formatINR(value)}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
}
