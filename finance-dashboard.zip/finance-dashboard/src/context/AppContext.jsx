import { createContext, useContext, useReducer, useEffect, useState } from 'react';
import { initialTransactions } from '../data/mockData';

const AppContext = createContext(null);

const LS_KEY = 'finflow_transactions';

function reducer(state, action) {
  switch (action.type) {
    case 'ADD_TRANSACTION':
      return { ...state, transactions: [action.payload, ...state.transactions] };
    case 'EDIT_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.map(t =>
          t.id === action.payload.id ? action.payload : t
        ),
      };
    case 'DELETE_TRANSACTION':
      return {
        ...state,
        transactions: state.transactions.filter(t => t.id !== action.payload),
      };
    case 'SET_FILTER':
      return { ...state, filter: action.payload };
    case 'SET_SEARCH':
      return { ...state, search: action.payload };
    case 'SET_SORT':
      return { ...state, sort: action.payload };
    case 'SET_ROLE':
      return { ...state, role: action.payload };
    default:
      return state;
  }
}

function loadTransactions() {
  try {
    const saved = localStorage.getItem(LS_KEY);
    return saved ? JSON.parse(saved) : initialTransactions;
  } catch {
    return initialTransactions;
  }
}

export function AppProvider({ children }) {
  const [state, dispatch] = useReducer(reducer, {
    transactions: loadTransactions(),
    filter: 'all',
    search: '',
    sort: { key: 'date', dir: 'desc' },
    role: 'admin',
  });

  const [darkMode, setDarkMode] = useState(() => {
    return localStorage.getItem('finflow_dark') === 'true';
  });

  useEffect(() => {
    localStorage.setItem(LS_KEY, JSON.stringify(state.transactions));
  }, [state.transactions]);

  useEffect(() => {
    document.documentElement.classList.toggle('dark', darkMode);
    localStorage.setItem('finflow_dark', darkMode);
  }, [darkMode]);

  return (
    <AppContext.Provider value={{ state, dispatch, darkMode, setDarkMode }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  return useContext(AppContext);
}
