import { useState } from 'react';
import Sidebar from './components/layout/Sidebar';
import DashboardPage from './components/dashboard/DashboardPage';
import TransactionsPage from './components/transactions/TransactionsPage';
import InsightsPage from './components/insights/InsightsPage';
import { AppProvider } from './context/AppContext';

function AppInner() {
  const [page, setPage] = useState('dashboard');

  return (
    <div className="flex min-h-screen">
      <Sidebar page={page} setPage={setPage} />
      <main className="flex-1 min-w-0 p-4 lg:p-8 overflow-y-auto">
        {page === 'dashboard'    && <DashboardPage setPage={setPage} />}
        {page === 'transactions' && <TransactionsPage />}
        {page === 'insights'     && <InsightsPage />}
      </main>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppInner />
    </AppProvider>
  );
}
