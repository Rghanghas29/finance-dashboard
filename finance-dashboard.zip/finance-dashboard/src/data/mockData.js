import { subDays, subMonths, format } from 'date-fns';

export const CATEGORIES = [
  'Food & Dining',
  'Shopping',
  'Transport',
  'Entertainment',
  'Healthcare',
  'Utilities',
  'Rent',
  'Salary',
  'Freelance',
  'Investment',
  'Education',
  'Travel',
];

export const CATEGORY_COLORS = {
  'Food & Dining':  '#22c55e',
  'Shopping':       '#3b82f6',
  'Transport':      '#f59e0b',
  'Entertainment':  '#a855f7',
  'Healthcare':     '#ec4899',
  'Utilities':      '#06b6d4',
  'Rent':           '#ef4444',
  'Salary':         '#10b981',
  'Freelance':      '#8b5cf6',
  'Investment':     '#f97316',
  'Education':      '#84cc16',
  'Travel':         '#14b8a6',
};

const seed = [
  // Incomes
  { id: '1',  date: format(subDays(new Date(), 1),  'yyyy-MM-dd'), description: 'Monthly Salary',       category: 'Salary',         type: 'income',  amount: 85000 },
  { id: '2',  date: format(subDays(new Date(), 5),  'yyyy-MM-dd'), description: 'Freelance Project',    category: 'Freelance',      type: 'income',  amount: 22000 },
  { id: '3',  date: format(subDays(new Date(), 10), 'yyyy-MM-dd'), description: 'Dividend Payout',      category: 'Investment',     type: 'income',  amount: 9500  },
  { id: '4',  date: format(subMonths(new Date(), 1).setDate(1), 'yyyy-MM-dd'), description: 'Monthly Salary', category: 'Salary', type: 'income', amount: 85000 },
  { id: '5',  date: format(subMonths(new Date(), 1).setDate(8), 'yyyy-MM-dd'), description: 'Side Project',   category: 'Freelance', type: 'income', amount: 15000 },
  { id: '6',  date: format(subMonths(new Date(), 2).setDate(1), 'yyyy-MM-dd'), description: 'Monthly Salary', category: 'Salary', type: 'income', amount: 85000 },
  { id: '7',  date: format(subMonths(new Date(), 2).setDate(12), 'yyyy-MM-dd'), description: 'Consulting Fee', category: 'Freelance', type: 'income', amount: 30000 },
  { id: '8',  date: format(subMonths(new Date(), 3).setDate(1), 'yyyy-MM-dd'), description: 'Monthly Salary', category: 'Salary', type: 'income', amount: 85000 },
  { id: '9',  date: format(subMonths(new Date(), 4).setDate(1), 'yyyy-MM-dd'), description: 'Monthly Salary', category: 'Salary', type: 'income', amount: 80000 },
  { id: '10', date: format(subMonths(new Date(), 5).setDate(1), 'yyyy-MM-dd'), description: 'Monthly Salary', category: 'Salary', type: 'income', amount: 80000 },

  // Expenses
  { id: '11', date: format(subDays(new Date(), 2),  'yyyy-MM-dd'), description: 'Apartment Rent',       category: 'Rent',           type: 'expense', amount: 22000 },
  { id: '12', date: format(subDays(new Date(), 3),  'yyyy-MM-dd'), description: 'Grocery Shopping',     category: 'Food & Dining',  type: 'expense', amount: 4200  },
  { id: '13', date: format(subDays(new Date(), 4),  'yyyy-MM-dd'), description: 'Netflix & Spotify',    category: 'Entertainment',  type: 'expense', amount: 1199  },
  { id: '14', date: format(subDays(new Date(), 6),  'yyyy-MM-dd'), description: 'Fuel',                 category: 'Transport',      type: 'expense', amount: 3500  },
  { id: '15', date: format(subDays(new Date(), 7),  'yyyy-MM-dd'), description: 'Restaurant Dinner',    category: 'Food & Dining',  type: 'expense', amount: 2800  },
  { id: '16', date: format(subDays(new Date(), 9),  'yyyy-MM-dd'), description: 'Electricity Bill',     category: 'Utilities',      type: 'expense', amount: 2100  },
  { id: '17', date: format(subDays(new Date(), 11), 'yyyy-MM-dd'), description: 'Online Course',        category: 'Education',      type: 'expense', amount: 4999  },
  { id: '18', date: format(subDays(new Date(), 14), 'yyyy-MM-dd'), description: 'Clothes Shopping',     category: 'Shopping',       type: 'expense', amount: 7500  },
  { id: '19', date: format(subDays(new Date(), 16), 'yyyy-MM-dd'), description: 'Doctor Visit',         category: 'Healthcare',     type: 'expense', amount: 1500  },
  { id: '20', date: format(subDays(new Date(), 18), 'yyyy-MM-dd'), description: 'Weekend Trip',         category: 'Travel',         type: 'expense', amount: 12000 },
  { id: '21', date: format(subDays(new Date(), 20), 'yyyy-MM-dd'), description: 'Uber Rides',           category: 'Transport',      type: 'expense', amount: 1800  },
  { id: '22', date: format(subDays(new Date(), 22), 'yyyy-MM-dd'), description: 'Books & Stationery',   category: 'Education',      type: 'expense', amount: 2200  },
  { id: '23', date: format(subMonths(new Date(), 1).setDate(3),  'yyyy-MM-dd'), description: 'Apartment Rent',    category: 'Rent',          type: 'expense', amount: 22000 },
  { id: '24', date: format(subMonths(new Date(), 1).setDate(5),  'yyyy-MM-dd'), description: 'Grocery Shopping',  category: 'Food & Dining', type: 'expense', amount: 3800  },
  { id: '25', date: format(subMonths(new Date(), 1).setDate(10), 'yyyy-MM-dd'), description: 'Internet Bill',     category: 'Utilities',     type: 'expense', amount: 999   },
  { id: '26', date: format(subMonths(new Date(), 1).setDate(14), 'yyyy-MM-dd'), description: 'Movie Tickets',     category: 'Entertainment', type: 'expense', amount: 800   },
  { id: '27', date: format(subMonths(new Date(), 1).setDate(18), 'yyyy-MM-dd'), description: 'Electronics',       category: 'Shopping',      type: 'expense', amount: 18000 },
  { id: '28', date: format(subMonths(new Date(), 2).setDate(3),  'yyyy-MM-dd'), description: 'Apartment Rent',    category: 'Rent',          type: 'expense', amount: 22000 },
  { id: '29', date: format(subMonths(new Date(), 2).setDate(7),  'yyyy-MM-dd'), description: 'Gym Membership',    category: 'Healthcare',    type: 'expense', amount: 1800  },
  { id: '30', date: format(subMonths(new Date(), 2).setDate(15), 'yyyy-MM-dd'), description: 'Flight Tickets',    category: 'Travel',        type: 'expense', amount: 25000 },
  { id: '31', date: format(subMonths(new Date(), 3).setDate(3),  'yyyy-MM-dd'), description: 'Apartment Rent',    category: 'Rent',          type: 'expense', amount: 22000 },
  { id: '32', date: format(subMonths(new Date(), 3).setDate(12), 'yyyy-MM-dd'), description: 'Clothing',          category: 'Shopping',      type: 'expense', amount: 9000  },
  { id: '33', date: format(subMonths(new Date(), 4).setDate(3),  'yyyy-MM-dd'), description: 'Apartment Rent',    category: 'Rent',          type: 'expense', amount: 22000 },
  { id: '34', date: format(subMonths(new Date(), 4).setDate(9),  'yyyy-MM-dd'), description: 'Dinner Out',        category: 'Food & Dining', type: 'expense', amount: 3200  },
  { id: '35', date: format(subMonths(new Date(), 5).setDate(3),  'yyyy-MM-dd'), description: 'Apartment Rent',    category: 'Rent',          type: 'expense', amount: 22000 },
  { id: '36', date: format(subMonths(new Date(), 5).setDate(20), 'yyyy-MM-dd'), description: 'Annual Insurance',  category: 'Healthcare',    type: 'expense', amount: 15000 },
];

export const initialTransactions = seed;

export function generateMonthlyData(transactions) {
  const months = [];
  for (let i = 5; i >= 0; i--) {
    const d = subMonths(new Date(), i);
    const label = format(d, 'MMM yyyy');
    const month = format(d, 'yyyy-MM');
    const income  = transactions.filter(t => t.type === 'income'  && t.date.startsWith(month)).reduce((s, t) => s + t.amount, 0);
    const expense = transactions.filter(t => t.type === 'expense' && t.date.startsWith(month)).reduce((s, t) => s + t.amount, 0);
    months.push({ label, income, expense, balance: income - expense });
  }
  return months;
}

export function generateCategoryData(transactions) {
  const expenseMap = {};
  transactions.filter(t => t.type === 'expense').forEach(t => {
    expenseMap[t.category] = (expenseMap[t.category] || 0) + t.amount;
  });
  return Object.entries(expenseMap)
    .map(([name, value]) => ({ name, value, fill: CATEGORY_COLORS[name] || '#888' }))
    .sort((a, b) => b.value - a.value);
}
